========================================
PyPDE: nonconservative-term correction
========================================

Independent patched distribution of Haran Jackson's PyPDE. Local version:
``1.0.0+tlpl.audit2``. This is not an official upstream release.

See ``README.md`` for the numerical correction and ``INSTALL.md`` for building
from this source. Installing the upstream PyPI package does not apply this patch.
The original README is retained as ``docs/UPSTREAM_README.rst``.
