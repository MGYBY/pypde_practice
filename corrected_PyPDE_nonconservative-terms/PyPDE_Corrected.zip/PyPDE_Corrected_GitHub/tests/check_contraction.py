#!/usr/bin/env python3
"""Check the disputed expressions, not the complete PDE algorithm (Linux/WSL)."""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import tempfile

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default=os.environ.get('CXX', 'c++'))
    parser.add_argument('--output', type=Path, default=Path('contraction_probe_local.json'))
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    compiler = shlex.split(args.compiler)
    if not compiler:
        parser.error('A compiler executable is required.')
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except ImportError:
        pass
    records = []
    with tempfile.TemporaryDirectory(prefix='pypde-contraction-') as tmp:
        executable = Path(tmp) / 'probe'
        command = compiler + ['-std=c++11', '-O0', '-UNDEBUG',
                              '-I' + str(root), '-I' + str(root / 'include'),
                              str(root / 'tests/contraction_probe.cpp'),
                              '-o', str(executable)]
        subprocess.run(command, check=True, timeout=120)
        for mode in ['fixed', 'old_dg', 'old_fv']:
            run = subprocess.run([str(executable), mode], capture_output=True, text=True, timeout=20)
            good = run.returncode == 0 if mode == 'fixed' else (
                run.returncode != 0 and 'invalid matrix product' in run.stderr.lower())
            if mode == 'fixed' and good:
                for label in ['DG result:', 'FV result:']:
                    line = next((s for s in run.stdout.splitlines() if s.startswith(label)), '')
                    values = [float(v) for v in line[len(label):].split()]
                    good = good and values == [0.0, 0.0, -24.0, -33.0]
            records.append(dict(mode=mode, passed=good, returncode=run.returncode,
                                stdout=run.stdout, stderr=run.stderr))
            print(mode + ': ' + ('PASS' if good else 'FAIL'))
    passed = all(row['passed'] for row in records)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    version = subprocess.run(compiler + ['--version'], capture_output=True, text=True, timeout=20)
    args.output.write_text(json.dumps(dict(
        scope='Expression-level debug assertion check; not a full PDE simulation',
        compiler=version.stdout.splitlines()[0] if version.stdout else args.compiler,
        passed=passed, cases=records), indent=2) + '\n')
    if not passed:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
