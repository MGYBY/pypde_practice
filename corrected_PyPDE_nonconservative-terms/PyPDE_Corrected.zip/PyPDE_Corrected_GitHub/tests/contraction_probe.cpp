#include "src/types.h"
#include <iostream>
#include <string>
#include <iomanip>
int main(int argc,char**argv){
  std::string mode=argc>1?argv[1]:"fixed";
  int V=4;Mat b=Mat::Zero(V,V);b(2,1)=2.;b(3,0)=3.;
  Mat dq(8,V);for(int i=0;i<8;++i)for(int j=0;j<V;++j)dq(i,j)=1.+10.*i+j;
  Mat rett=Mat::Zero(8,V);Vec s=Vec::Zero(V);int idx=1;
  std::cout<<std::setprecision(17)<<"B:\n"<<b<<"\ngradient: "<<dq.row(idx)<<std::endl;
  std::cout<<"expected -B*gradient: "<<(-b*dq.row(idx).transpose()).transpose()<<std::endl;
  if(mode=="old_dg") rett.row(idx)-=b*dq.row(idx);
  else if(mode=="old_fv") s-=b*dq.row(idx);
  else {rett.row(idx)-=(b*dq.row(idx).transpose()).transpose();s-=b*dq.row(idx).transpose();}
  std::cout<<"DG result: "<<rett.row(idx)<<"\nFV result: "<<s.transpose()<<std::endl;
}
