# Local revision: 1.0.0+tlpl.audit2

Native corrections originally prepared on 23 September 2026, based on the
uploaded PyPDE-master source. Haran Jackson's authorship and the original license
are retained. This is not an official upstream release.

1. Correct row/column contractions in the DG predictor and FV interior B-gradient products.
2. Correct absent-F gradient-dependence detection and guard the corresponding native call.
3. Replace unsafe NaN output-row writes with native error propagation.
4. Retrieve worker exceptions, reject non-finite stages/matrices and invalid time progress.
5. Expose error status and correction markers to the ctypes wrapper.

[README.md](README.md) explains the principal numerical error.
[VALIDATION.md](VALIDATION.md) describes the previously executed tests and their limits.
[evidence/full_native_patch.diff](evidence/full_native_patch.diff) records all native
revision changes relative to the original uploaded source.
[PACKAGING.md](PACKAGING.md) records subsequent documentation-only packaging changes.

The isolated two-statement patch is not the complete safety revision. This focused
audit does not validate every multidimensional/parabolic feature, callback, or
physical state branch supported by the parent library.
