# Validation details for the nonconservative-term correction

This note summarizes the previously executed local re-audit. The numerical trajectories below come from the prior re-audit; no new roll-wave simulations were run when packaging this release. A small C++ contraction check was rerun separately, as recorded in `evidence/contraction_probe_repackaging.json`. The records below document the inspected source and tested configurations; they are not an upstream acknowledgment or a validation of every PyPDE application.

## Source and build provenance

The audit used the uploaded original `PyPDE-master(4).zip`, the native source bundled with front-runner v2, and a third build obtained from the original by applying only [the two-statement patch](evidence/two_line_only.patch).

Original archive SHA-256:

```text
e3df26df6c45f5386e3ef39fb7eaeb963e692c82b88abfeb369c2ce08dbe5674
```

The revised native distribution identifies itself as `1.0.0+tlpl.audit2`, a local version identifier, not an official upstream release. No upstream commit identity is inferred from the ZIP filename.

The recorded environment was Python 3.13.5, NumPy 2.3.5, Numba 0.65.1, SciPy 1.17.0, CMake 3.31.6, g++ 14.2.0, and the uploaded Eigen 3.3.7. See [source audit](evidence/source_audit.json) and [isolated native build records](evidence/build_status.json). Invalid original expressions are not guaranteed to give identical numerical outputs with other compilers or Eigen versions.

## Independent checks

The [C++ contraction probe](evidence/contraction_probe.json) records Eigen assertion failures for both original expressions and the expected complete product for both corrected expressions. The separate Python-to-C callback check found no transposition error in the supplied `B(Q)` matrix.

The two-layer smooth-wave test compared the native nonlinear calculation with the independent linearized matrix-exponential solution:

$$
\widehat{\mathbf Q}(T)=\exp[(\mathbf C_0-\mathrm{i}k\mathbf A_0)T]\widehat{\mathbf Q}(0),
\qquad
\mathbf A_0=\mathbf F_{,\mathbf Q}+\mathbf B,
\quad \mathbf C_0=\mathbf S_{,\mathbf Q}.
$$

It used `L_X = 8`, `T = 0.12`, and disturbance amplitude `1e-5`. The reported relative error is the norm of the difference between the numerical and reference complex four-component Fourier coefficients, divided by the reference norm. At 256 cells it was 2.09432% for the original and 0.002061% for the corrected library. The original error stalled near 2.1%; the corrected error decreased over 32, 64, 128, and 256 cells.

A separate constant-matrix test, without the power-law closure, compared the equivalent formulations `F = DQ, B = K` and `F = (D+K)Q, B = 0`. After correction, the two numerical solutions agreed pointwise to approximately `9.68e-13` at 256 cells. See [original analytical-test results](evidence/linear_original.json) and [corrected analytical-test results](evidence/linear_corrected.json).

## Matched nonlinear periodic benchmark

```text
Fr_lower = 0.60
n_lower = 0.40; n_upper = 0.80
h_upper0 / h_lower0 = 1.0
rho_upper / rho_lower = 0.8
R_eta,I = eta_lower,I / eta_upper,I = 1.544
L_X = wavelength = 5
initial condition = free-surface eigenmode of the intended model
initial free-surface amplitude / H_lower = 0.001
reconstruction order = 2; Rusanov flux; CFL = 0.5
periodic boundaries; one native thread; stiff = False
output/restart interval = 0.25; final T = 24
```

Coordinates are `X = S0*x/H_lower` and `T = S0*t*Ubar_lower/H_lower`; depths use `H_lower`. Each original/corrected pair used identical initial-state bytes and unchanged model callbacks. Runs were completed on 75 and 150 cells; the two-line-only control also used 150 cells.

At `T = 24`, the 150-cell free-surface peak-to-trough heights were 1.170660 (original) and 0.846611 (corrected), in units of `H_lower`. The difference persisted after phase alignment and on the 75-cell grid. The two-line-only and full-v2 runs had a maximum absolute difference of zero over all four fields and all 97 saved times on the 150-cell grid. See [comparison summary](evidence/comparison_summary.json) and [metrics table](evidence/periodic_summary.tsv).

These are finite-time, finite-resolution comparisons, not exact permanent-wave amplitudes. The corrected wave height still varied over `T = 20..24`, and the extrema remained resolution-sensitive. Conservation and stored-frame admissibility checks do not independently validate all internal reconstructed stages or the physical KP closure.

## Published and source references

Jackson, H. (2017). *On the eigenvalues of the ADER-WENO Galerkin predictor*. Journal of Computational Physics, 333, 409–413. [DOI](https://doi.org/10.1016/j.jcp.2016.12.058); [Cambridge repository](https://www.repository.cam.ac.uk/handle/1810/264258). Eq. (9b) gives the nodal matrix–gradient contraction.

Jackson, H. (2019). *A Unified Framework for Simulating Impact-Induced Detonation of a Combustible Material in an Elasto-Plastic Confiner*. PhD thesis, University of Cambridge. Section 0.3.3, Eq. (49c), printed page 20 (PDF page 40), gives the cell-interior nonconservative integral; Eq. (55) separately gives the interface path matrix. The research PDFs are not redistributed here.

Public source inspected: [DG predictor](https://github.com/haranjackson/PyPDE/blob/master/src/solvers/dg/dg.cpp), [FV cell update](https://github.com/haranjackson/PyPDE/blob/master/src/solvers/fv/fv.cpp). These branch links may change; the recorded ZIP checksum identifies the original audit input.

## Reproduction material

This source distribution contains the complete corrected native library, numerical result records, the isolated patch, and the complete original-to-corrected native diff. It also includes a standalone C++ expression reproducer:

```bash
python tests/check_contraction.py
```

This short test checks the exact disputed expressions against the bundled Eigen headers; it is not a full PDE-solver or roll-wave validation. It deliberately runs the two invalid expressions in child processes and requires their debug assertions to fail.

The two-layer application model, raw trajectories, and complete simulation-reproduction scripts are not included in this native-library archive. They remain in the separately supplied `PyPDE_Jackson_Reaudit_and_Periodic_Comparison.zip` audit package. To reproduce the numerical table publicly, publish that companion package or the relevant application tests and raw data alongside this source.
