# GitHub source packaging notes

This archive contains the complete corrected native source from
`PyPDE_1.0.0_TLPL_Audited_Source.zip`, identical to the vendor source in
`Two_Layer_PowerLaw_FrontRunner_PyPDE_v2.zip`. The native version remains
`1.0.0+tlpl.audit2`; no new computational correction was introduced in this repackaging.

Every file under `src/`, `pypde/`, and `include/`, together with `setup.py`,
`CMakeLists.txt`, `requirements.txt`, and `LICENSE`, is byte-for-byte unchanged.
The file-level comparison is recorded in
[evidence/packaging_verification.json](evidence/packaging_verification.json).

Documentation and packaging changes:

- Added the concise README, installation and validation notes, numerical evidence,
  a full native diff, and an expression-level regression check.
- Kept the original README as `docs/UPSTREAM_README.rst`; the root RST now
  identifies the patched package rather than directing readers to the unpatched
  upstream package-index installation.
- Preserved the inherited automatic build/PyPI-publish workflow as
  `docs/upstream_workflows/main.yml.disabled`. There is deliberately no active
  publishing workflow in this archive.
- Extended `.gitignore` for local build/cache products.

Original authorship, the AGPL license, and the bundled third-party headers and
notices remain intact. No research PDFs, compiled libraries, or font files are
included. Upload the extracted directory contents to the repository root, so
`README.md`, `setup.py`, `src/`, and `pypde/` remain together.

This packaging pass did not rebuild the entire native library or rerun the
matched roll-wave simulations. Those evidence records are explicitly historical.
The small C++ expression check was rerun separately.
