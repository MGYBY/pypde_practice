#include "solvers/iterator.h"
#include "solvers/weno/weno.h"
#include "types.h"
#include <exception>
#include <iostream>
#include <limits>
#include <string>

// TLPL safety patch: no C++ exception crosses the ctypes C ABI.
static thread_local std::string pypde_error_message;
extern "C" int pypde_safety_api_version() { return 1; }
// Marker for corrected B * gradient contractions in DG and FV.
extern "C" int pypde_nonconservative_api_version() { return 1; }
extern "C" const char *pypde_last_error() { return pypde_error_message.c_str(); }

extern "C" void pde_solver(void (*F)(double *, double *, double *, int),
                           void (*B)(double *, double *, int),
                           void (*S)(double *, double *), bool useF, bool useB,
                           bool useS, double *_u, double tf, int *_nX, int ndim,
                           double *_dX, double CFL, int *_boundaryTypes,
                           bool STIFF, int FLUX, int N, int V, int ndt,
                           bool secondOrder, double *_ret, int nThreads) {

  iVecMap nX(_nX, ndim);
  VecMap dX(_dX, ndim);
  iVecMap boundaryTypes(_boundaryTypes, ndim);

  int ncell = nX.prod();
  MatMap u(_u, ncell, V, OuterStride(V));
  MatMap ret(_ret, ndt, ncell * V, OuterStride(ncell * V));

  if (!useF)
    F = NULL;
  if (!useB)
    B = NULL;
  if (!useS)
    S = NULL;

  pypde_error_message.clear();
  try {
    iterator(F, B, S, u, tf, nX, dX, CFL, boundaryTypes, STIFF, FLUX, N, ndt,
             secondOrder, ret, nThreads);
  } catch (const std::exception &error) {
    pypde_error_message = error.what();
    ret.setConstant(std::numeric_limits<double>::quiet_NaN());
    std::cerr << "PyPDE stopped: " << pypde_error_message << "\n";
  } catch (...) {
    pypde_error_message = "Unknown native solver exception";
    ret.setConstant(std::numeric_limits<double>::quiet_NaN());
    std::cerr << "PyPDE stopped: " << pypde_error_message << "\n";
  }
}

extern "C" void weno_solver(double *ret, double *_u, int *_nX, int ndim, int N,
                            int V) {

  iVecMap nX(_nX, ndim);

  WenoSolver wenoSolver(nX, N, V);

  int ncell = nX.prod();
  MatMap u(_u, ncell, V, OuterStride(V));

  Mat wh = wenoSolver.reconstruction(u);

  VecMap whVec(wh.data(), wh.size());

  for (int i = 0; i < whVec.size(); i++)
    ret[i] = whVec(i);
}