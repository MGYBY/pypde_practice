# Building the corrected native library

The compiled C++ library must be rebuilt from this source. Installing `pypde`
from the upstream package index, or replacing only a simulation script, does not
apply the corrections. This is Haran Jackson's `from pypde import pde_solver`,
not the unrelated `py-pde` library imported as `pde`.

## Linux / WSL source installation

A C++11 compiler, Python development headers, and CMake must be available.
The bundled `include/` tree contains the Eigen and Spectra headers.
The prior native audit used g++ 14.2.0, CMake 3.31.6, and Python 3.13.5;
see [VALIDATION.md](VALIDATION.md) for the other versions. Windows and macOS
were not tested by this audit.

From the directory containing `setup.py`:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel 'cmake>=3.5,<4'
python -m pip install -r requirements.txt
CMAKE_BUILD_PARALLEL_LEVEL=2 python -m pip install --no-build-isolation --no-cache-dir .
```

CMake 3.x is used here to match the legacy build configuration. A fresh virtual
environment avoids inadvertently using an older library with the same module name.
These commands install this local source; no PyPI publication is performed.

## Confirm the installation

First change out of the source root, so its unbuilt `pypde/` directory does not
shadow the installed package:

```bash
cd ..
python -c "from importlib.metadata import version; import pypde; print(version('PyPDE')); print(pypde.__file__)"
```

The version should be `1.0.0+tlpl.audit2` and the module path should point into the
selected environment's `site-packages` directory. Restart an already-running
Python process or notebook after replacing its native library.

## Small expression-level check

From the source root, run:

```bash
python tests/check_contraction.py
```

Only a C++ compiler is required for this check. The runner compiles in a temporary
directory using the bundled Eigen headers. It verifies the corrected results and
expects both original expressions to trigger debug assertions in child processes.
It does not run a roll-wave simulation or require an installed `pypde`.

The example command uses a GCC/Clang-compatible compiler; set `--compiler` to its
executable, or use the `CXX` environment variable. The default output is
`contraction_probe_local.json` in the current directory.

## Application-level cautions

Retain an independent initial-state copy when calling this inherited API: pass
`Q_initial.copy()` to `pde_solver`, because its work array can be modified in place.
Use a C-contiguous, `float64` state and explicitly set a positive thread count.
Recheck application growth rates, wave speeds, and grid/timestep convergence.

The two-layer front-runner and periodic-wave drivers are separate applications;
they are not required to install this general native library. Full matched-wave
reproduction remains in the companion re-audit package.

Original installation reference:
[PyPDE documentation](https://pypde.readthedocs.io/en/latest/pages/installation.html).
